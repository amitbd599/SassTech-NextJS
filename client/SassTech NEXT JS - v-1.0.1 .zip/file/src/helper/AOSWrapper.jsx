import React from "react";

const AOSWrapper = ({ children }) => {
  return <>{children}</>;
};

export default AOSWrapper;
