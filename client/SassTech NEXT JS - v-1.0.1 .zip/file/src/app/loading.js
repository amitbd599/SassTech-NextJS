export default function Loading() {
  return (
    <div className='preloader'>
      <div className='cssload-loading'>
        <i />
        <i />
        <i />
        <i />
      </div>
    </div>
  );
}
